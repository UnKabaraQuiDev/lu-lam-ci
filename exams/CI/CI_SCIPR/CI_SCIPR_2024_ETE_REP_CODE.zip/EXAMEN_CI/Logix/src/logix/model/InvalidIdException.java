package logix.model;

public class InvalidIdException extends Exception {

    public InvalidIdException(String explanation) {
        super(explanation);
    }
    
}