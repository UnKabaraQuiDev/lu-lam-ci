package logix.model;

public class MaximumInputLimitReachedException extends Exception {

    public MaximumInputLimitReachedException(String explanation) {
        super(explanation);
    }
    
}