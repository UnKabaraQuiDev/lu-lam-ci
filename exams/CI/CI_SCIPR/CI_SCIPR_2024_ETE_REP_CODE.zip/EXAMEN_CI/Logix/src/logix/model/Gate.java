package logix.model;

import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;

public abstract class Gate {
    // some constants
    public final static int HEIGHT = 35;
    public final static int WIDTH = 50;
    // outputs
    protected ArrayList<Gate> alOutputs = new ArrayList<>();
    // inputs
    protected ArrayList<Gate> alInputs = new ArrayList<>();
    protected int maxInputCount; // = 0 (default value)
    // id
    String id;
    // position
    protected int x;
    protected int y;
    // state
    protected boolean state;  

    
    // GIVEN: basic drawing
    public void draw(Graphics g)                                     
    {
        // active
        if(state)
        {
            g.setColor(Color.YELLOW);
            g.fillRect(x, y, WIDTH, HEIGHT);
        }
        // border
        g.setColor(Color.BLACK);
        g.drawRect(x, y, WIDTH, HEIGHT);
        // ID
        g.drawString(id,x+5,y+HEIGHT-5);
        
        //color of connections
        if(state)
            g.setColor(Color.RED);
        else
            g.setColor(Color.GRAY);
        // connections
        for (int i = 0; i < alOutputs.size(); i++) {
            Gate other = alOutputs.get(i);
            drawConnectionTo(g,other);
        }
    }
    
    // GIVEN: draw the connection between two gates
    private void drawConnectionTo(Graphics g, Gate other)             
    {
        int deltaX = other.x-x;
        int deltaY = other.y-y;

        if(deltaX>0)
        {
            g.drawLine(x+WIDTH            , y+HEIGHT/2      , 
                    (x+WIDTH+other.x)/2, y+HEIGHT/2);
            g.drawLine((x+WIDTH+other.x)/2, y+HEIGHT/2      , 
                    (x+WIDTH+other.x)/2, other.y+HEIGHT/2);
            g.drawLine((x+WIDTH+other.x)/2, other.y+HEIGHT/2, 
                    other.x            , other.y+HEIGHT/2);
        }
        else
        {
            int offsetY = 0;
            if(deltaY<0)
                offsetY=HEIGHT;

            g.drawArc(x+WIDTH-HEIGHT/2, y+HEIGHT/2-offsetY        , 
                    HEIGHT, HEIGHT, -90, 180);
            g.drawLine(x+WIDTH        ,y+HEIGHT+HEIGHT/2-2*offsetY,
                    other.x,other.y-HEIGHT/2+2*offsetY);
            g.drawArc(other.x-HEIGHT/2, other.y-HEIGHT/2+offsetY  , 
                    HEIGHT, HEIGHT, 90 , 180);
        }
    }    
}
