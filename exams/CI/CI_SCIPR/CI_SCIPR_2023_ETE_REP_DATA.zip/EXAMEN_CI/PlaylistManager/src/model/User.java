package model;

import java.awt.Graphics;

public class User {
    
    public void draw(Graphics g, int width, int height){
        // à compléter!
    }
}
