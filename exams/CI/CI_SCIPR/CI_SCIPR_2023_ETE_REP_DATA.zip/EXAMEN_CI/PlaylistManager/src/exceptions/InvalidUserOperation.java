package exceptions;

///////////////////////////////////////////
//
// classe fournie
//
///////////////////////////////////////////
public class InvalidUserOperation extends Exception{
    
    public InvalidUserOperation(String message){
        super(message);
    }
}
