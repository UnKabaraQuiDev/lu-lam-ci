/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exceptions;

/**
 *
 * @author Elder
 */
public class InvalidElementException extends Exception{
    
    public InvalidElementException(String message){
        super(message);
    }
}
