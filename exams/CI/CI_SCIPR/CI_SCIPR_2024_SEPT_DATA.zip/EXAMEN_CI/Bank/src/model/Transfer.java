package model;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author
 */

public class Transfer {

    private Account sender;
    private Account receiver;
    private double amount;
    private String currency;


    public Transfer(Account sender, Account receiver, double amount){
        this.sender = sender;
        this.receiver = receiver;
        this.amount = amount;
        this.currency = sender.getCurrency();
    }
}
