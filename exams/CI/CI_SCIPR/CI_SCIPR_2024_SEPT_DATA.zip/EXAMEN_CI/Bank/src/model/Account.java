package model;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author
 */

public class Account{

    private int number;
    private String username;
    private double balance;
    private String currency;

    public Account(int number, String username, double balance, String currency) {
        this.number = number;
        this.username = username;
        this.balance = balance;
        this.currency = currency;
    }

    public String getUsername() {
        return username;
    }

    public double getBalance() {
        return balance;
    }

    public String getCurrency() {
        return currency;
    }

    public int getNumber() {
        return number;
    }
    
    public void receiveMoney(double amount){
        this.balance += amount;
    }
    
    public void withdrawMoney(double amount){
        this.balance -= amount;
    }
    
}
