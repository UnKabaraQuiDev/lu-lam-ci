package lu.model;

public class Node {

    private SpaceObject spaceObject;
    private Node next = null;

    public Node(SpaceObject spaceObject) {
        this.spaceObject = spaceObject;
    }

    public SpaceObject getSpaceObject() {
        return spaceObject;
    }

    public Node getNext() {
        return next;
    }

    public void setNext(Node next) {
        this.next = next;
    }
}
