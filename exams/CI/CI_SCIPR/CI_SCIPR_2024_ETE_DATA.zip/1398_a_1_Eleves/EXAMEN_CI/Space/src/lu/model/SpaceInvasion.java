package lu.model;

import java.awt.Graphics;

import java.io.IOException;

public class SpaceInvasion {

    public SpaceInvasion(int screenWidth, int screenHeight) {
    }

    public void add(SpaceObject spaceObject) {

    }

    public Object[] toArray() {
        return null;
    }

    public boolean gameOver() {
        return false;
    }

    public void drawAll(Graphics g) {

    }

    public void moveAll(int screenWidth) {

    }

    public void checkHit() {

    }

    public void movePlayer(int steps) {

    }

    public void shoot() {

    }

    public void removeAllObsolete(int screenHeight) {

    }

    public void loadFromFile(String fileName) throws IOException {

    }
}
