package lu.model;

public class SpaceObject {

}
