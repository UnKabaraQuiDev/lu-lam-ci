package lu.ci.examen.minigis.model;

public class CityTour {

    public void add(PointOfInterest pointOfInterest) {
        // to be coded
    }
    
}
