package lu.ci.examen.minigis.model;

import java.io.IOException;

public class Track {

    public void loadFromFile(String visite_1track) throws IOException {
        // to be coded
    }

    public Object[] toArray() {
        // to be coded
        return null; 
    }

    public void saveToFile(String new_tracktrack) throws IOException {
        // to be coded
    }

    public void clear() {
        // to be coded
    }
    
}
