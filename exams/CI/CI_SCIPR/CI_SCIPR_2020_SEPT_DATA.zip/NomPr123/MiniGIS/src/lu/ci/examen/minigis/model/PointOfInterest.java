package lu.ci.examen.minigis.model;

public class PointOfInterest {

    public PointOfInterest(int x, int y, int radius) {
        // to be coded
    }
    
}
