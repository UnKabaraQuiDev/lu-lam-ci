package lu.ci.scipr.railroad.model;

public class Train{

    private String origin;
    private String destination;
    private int arrivalHour;
    private int arrivalMinute;
    private int size = 0;

    public Train(String origin, String destination, int arrivalHour, int arrivalMinute) {
        this.origin = origin;
        this.destination = destination;
        this.arrivalHour = arrivalHour;
        this.arrivalMinute = arrivalMinute;
    }
    
    @Override
    public String toString() {
        return arrivalHour + "h" + arrivalMinute + " - " + origin + " -> " + destination;
    }    

    public int size() {
        return size;
    }
}
