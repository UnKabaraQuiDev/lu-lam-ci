/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;

/**
 *
 * @author robert.fisch
 */
public class ReliableBTC extends BTC {
    
    public ReliableBTC(String date, double price, int hash) {
        super(date, price, hash);
    }
    
    @Override
    public Point draw(Graphics g, int x, int height, double pixelPerEuro)
    {
        g.setColor(Color.BLUE);
        return super.draw(g, x, height, pixelPerEuro);
    }
}
