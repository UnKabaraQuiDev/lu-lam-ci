/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.util.NoSuchElementException;

/**
 *
 * @author robert.fisch
 */
public class Market {
    private Node root;
    
    public void add(BTC btc)
    {
        if(root==null)
            root=new Node(btc);
        else
        {
            Node tmp = root;
            while(tmp.getNext()!=null)
                tmp=tmp.getNext();
            tmp.setNext(new Node(btc));
        }
    }
    
    public int size()
    {
        Node tmp = root;
        int count=0;
        while(tmp!=null)
        {
            tmp=tmp.getNext();
            count++;
        }
        return count;
    }
    
    public Object[] toArray()
    {
        Object[] result = new Object[size()];
        Node tmp = root;
        int count=0;
        while(tmp!=null)
        {
            result[count]=tmp.getData();
            tmp=tmp.getNext();
            count++;
        }
        return result;
    }
    
    public double max() throws NoSuchElementException
    {
        if(root==null) throw new NoSuchElementException();
        return max(root);
    }
    
    private double max(Node n)
    {
        if(n==null) return 0;
        double sub = max(n.getNext());
        double act = n.getData().getPrice();
        if(sub>act)
            return sub;
        else 
            return act;
    }
    
    public boolean isValidHash(int hash)
    {
        String syms = String.valueOf(hash);
        int sum = 0;
        for (int i = 0; i < syms.length(); i++) {
            sum+=Integer.valueOf(syms.charAt(i));
        }
        return sum%2==0;
    }
    
    public void readMArketFromFile(String fileName) throws IOException
    {
        root = null;
        try (BufferedReader in = new BufferedReader(new FileReader(fileName, StandardCharsets.UTF_8))) {
            String line;
            while ((line = in.readLine()) != null) { 
                String[] pieces = line.split(",");
                BTC btc;
                if(isValidHash(Integer.valueOf(pieces[2])))
                    btc=new ReliableBTC(pieces[0], Double.valueOf(pieces[1]), Integer.valueOf(pieces[2]));
                else
                    btc=new UnreliableBTC(pieces[0], Double.valueOf(pieces[1]), Integer.valueOf(pieces[2]));
                add(btc);
            }
        }
    }
    
    public void saveAsJson() throws IOException
    {
        try (PrintWriter out = new PrintWriter(new FileWriter("bitcoin.json", StandardCharsets.UTF_8))) {

            out.println("{");
            Node tmp = root;
            while(tmp!=null)
            {
                out.print("\""+tmp.getData().getDate()+"\": "+tmp.getData().getPrice());
                if(tmp.hasNext())
                    out.println(",");
                else
                    out.println("");
                tmp=tmp.getNext();
            }
            out.println("}");
        }
    }
    
    public void draw(Graphics g, int width, int height)
    {
        try
        {
            double max = max();
            double dx = (double)width/size();
            double x = 0;
            double pixelPerEuro = height/max;
            
            Node tmp = root;
            Point last = null;
            while(tmp!=null)
            {
                Point actual = tmp.getData().draw(g, (int)(x), height, pixelPerEuro);
                if(last!=null)
                {
                    g.setColor(Color.BLACK);
                    g.drawLine(last.x, last.y, actual.x, actual.y);
                }
                tmp=tmp.getNext();
                last = actual;
                x+=dx;
            }
            
            g.setColor(new Color(200,200,200));
            for(int i=0; i<max; i+=4000)
            {
                int y = height-(int)(i*pixelPerEuro);
                g.drawLine(0, y, width, y);
                g.drawString(i+"", 10, y-2);
            }
        }
        catch(NoSuchElementException e)
        {
            // do nothing
        }
        
    }
}
