/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.awt.Graphics;
import java.awt.Point;

/**
 *
 * @author robert.fisch
 */
public abstract class BTC {
    private String date;
    private double price;
    private int hash;
    private int radius = 2;

    public BTC(String date, double price, int hash) {
        this.date = date;
        this.price = price;
        this.hash = hash;
    }

    public String getDate() {
        return date;
    }

    public double getPrice() {
        return price;
    }
    
    public Point draw(Graphics g, int x, int height, double pixelPerEuro)
    {
        int y = (int)(height-price*pixelPerEuro);
        g.fillOval(x-radius, y-radius, 2*radius, 2*radius);
        return new Point(x,y);
    }

    @Override
    public String toString() {
        return date+": "+price+"€";
    }
    
    
}
