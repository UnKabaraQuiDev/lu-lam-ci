/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author robert.fisch
 */
public class Node {
    private Node next;
    private BTC data;

    public Node(BTC data) {
        this.data = data;
    }

    public Node getNext() {
        return next;
    }

    public void setNext(Node next) {
        this.next = next;
    }

    public BTC getData() {
        return data;
    }

    public void setData(BTC data) {
        this.data = data;
    }
    
    public boolean hasNext()
    {
        return next!=null;
    }

    @Override
    public String toString() {
        return data.toString();
    }
    
    
}
