/**
 * Write a description of class "Product" here.
 * 
 * @author     nicolas
 * @version    21/01/2026 09:59:52
 */
public class Article
{
}