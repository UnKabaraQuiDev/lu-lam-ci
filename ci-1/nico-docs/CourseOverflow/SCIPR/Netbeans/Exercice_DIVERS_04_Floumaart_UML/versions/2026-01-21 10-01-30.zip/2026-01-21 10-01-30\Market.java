/**
 * Write a description of class "Market" here.
 * 
 * @author     nicolas
 * @version    21/01/2026 09:59:39
 */
public class Market
{
}