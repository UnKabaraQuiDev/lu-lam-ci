/**
 * Write a description of class "Stats" here.
 * 
 * @author     nicolas
 * @version    21/01/2026 10:00:19
 */
public class Stats
{
	private ArrayList<Payment> alPayments = new ArrayList<>();
}