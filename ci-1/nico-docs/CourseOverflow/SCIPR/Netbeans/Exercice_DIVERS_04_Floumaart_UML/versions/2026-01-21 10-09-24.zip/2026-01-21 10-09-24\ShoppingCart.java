/**
 * Write a description of class "ShoppingCart" here.
 * 
 * @author     nicolas
 * @version    21/01/2026 10:00:27
 */
public class ShoppingCart
{
	private ArrayList<Article> alArticles = new ArrayList<>();

	public void add(Article article) {
		
	}

	public void remove(Article article) {
		
	}
}