/**
 * Write a description of class "Cashier" here.
 * 
 * @author     nicolas
 * @version    21/01/2026 10:00:08
 */
public class Cashier
{
	private String user;
	private String password;

	public int collectPayment(ShoppingCart shoppingCart, String payMethod, Client client) {
		
	}

	public void createPayment(Payment payment) {
		
	}
}